# Amigos
Amigos Project

## Start the app
Clone or download the repository from `https://github.com/kielsoft/elev8_amigos`

Run `npm install` to install all the necessary packages.
Run `npm run start:dev` for a dev server.

Use this local like the app has started successfully `http://localhost:4000` for a dev server.
