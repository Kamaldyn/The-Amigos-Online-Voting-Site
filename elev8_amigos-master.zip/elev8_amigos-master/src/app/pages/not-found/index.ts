import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'NotFoundPage',
  templateUrl: './template.html',
  styleUrls: ['./style.scss']
})
export class NotFoundPage implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
