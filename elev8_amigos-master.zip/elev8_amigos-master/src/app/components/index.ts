import { MainHeaderComponent } from "./main-header";

export const components = [
    MainHeaderComponent,
]